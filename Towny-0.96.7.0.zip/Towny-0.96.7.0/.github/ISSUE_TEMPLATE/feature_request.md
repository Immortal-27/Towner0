---
name: Feature request
about: Suggest an idea for this project
title: 'Suggestion: '
labels: enhancement
assignees: ''

---

**Please explain your feature request to the best of your abilities:**
