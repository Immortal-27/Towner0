package com.palmergames.bukkit.towny.object;

/**
 * @deprecated as of 0.95.2.15, use {@link EconomyAccount} instead.
 * 
 * @author LlmDl
 */
@Deprecated
public class TownyEconomyObject {

}
