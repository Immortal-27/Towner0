package com.palmergames.bukkit.towny.war.eventwar;

import com.palmergames.bukkit.towny.object.EconomyAccount;

public class WarSpoils extends EconomyAccount {

	public WarSpoils() {
		super("towny-war-chest");
	}
}