package com.palmergames.bukkit.towny.exceptions;

import com.palmergames.bukkit.towny.exceptions.TownyException;

public class MetaDataSerializationException extends TownyException {
	private static final long serialVersionUID = -5272182994988841260L;
    
}
