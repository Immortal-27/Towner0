package com.palmergames.bukkit.config.migration;

public enum MigrationType {
	OVERWRITE,
	APPEND,
	NATION_LEVEL_ADD,
	TOWN_LEVEL_ADD
}
