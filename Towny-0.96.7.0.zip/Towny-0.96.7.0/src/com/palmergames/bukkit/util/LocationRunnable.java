package com.palmergames.bukkit.util;

import org.bukkit.Location;

/**
 * @author Chris H (Zren / Shade)
 *         Date: 4/15/12
 */
public interface LocationRunnable {

	void run(Location loc);
}
